const router = require('express').Router();

const students = [
    {
        name: "Jack Dan",
        DOB: "8/4/1997",
        program: "BSC ICT",
        level: "300",
        image:"/images/img1.jpg"
    },
    {
        name: "Maxwel Asare",
        DOB: "8/4/1997",
        program: "BSC ICT",
        level: "400",
        image:"/images/img2.jpg"
    },
    {
        name: "Jonathan Mose",
        DOB: "8/4/1995",
        program: "BSC ICT",
        level: "400",
        image:"/images/img3.jpg"
    },

]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;