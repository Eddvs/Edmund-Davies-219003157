$(document).ready(function (){
    $("#patients").DataTable()
})