var sql = require("mssql");
 // config for your database
 var config = {
    user: 'DB_A2A9C5_db_admin',
    password: 'pass@word123',
    server: 'sql6009.site4now.net', 
    database: 'DB_A2A9C5_db' 
};

module.exports=config;